import { Canvas } from '@react-three/fiber'
import { OrbitControls, PerspectiveCamera } from '@react-three/drei'
import VoxelArt from './VoxelArt'
import '../styles/VoxelViewer.css'

export default function VoxelViewer({ voxelData, interactive = true }) {
  return (
    <div className="voxel-viewer-container">
      <Canvas>
        <PerspectiveCamera makeDefault position={[15, 15, 15]} />
        <ambientLight intensity={0.7} />
        <pointLight position={[10, 10, 10]} intensity={0.8} />
        <pointLight position={[-10, -10, 10]} intensity={0.5} color="#00ffff" />
        
        <VoxelArt voxelData={voxelData} />
        
        {interactive && <OrbitControls />}
      </Canvas>
    </div>
  )
}
  