import { useState, useCallback } from 'react'
import VoxelViewer from './VoxelViewer'
import '../styles/VoxelEditor.css'

export default function VoxelEditor({ initialVoxels = null, onSave = null }) {
  const [voxels, setVoxels] = useState(initialVoxels || generateEmptyGrid())
  const [selectedColor, setSelectedColor] = useState('#FF0000')
  const [brushSize, setBrushSize] = useState(1)
  const [gridSize] = useState(16)

  function generateEmptyGrid() {
    const grid = []
    for (let x = 0; x < gridSize; x++) {
      for (let y = 0; y < gridSize; y++) {
        for (let z = 0; z < gridSize; z++) {
          grid.push({ x, y, z, color: '#FFFFFF', active: false })
        }
      }
    }
    return grid
  }

  const handleVoxelClick = useCallback((voxelIndex) => {
    setVoxels(prev => {
      const updated = [...prev]
      updated[voxelIndex].active = !updated[voxelIndex].active
      updated[voxelIndex].color = selectedColor
      return updated
    })
  }, [selectedColor])

  const handleClear = useCallback(() => {
    setVoxels(generateEmptyGrid())
  }, [])

  const handleSave = useCallback(() => {
    if (onSave) {
      onSave(voxels)
    }
  }, [voxels, onSave])

  return (
    <div className="voxel-editor-container">
      <div className="editor-controls">
        <div className="color-picker">
          <label>Color:</label>
          <input 
            type="color" 
            value={selectedColor} 
            onChange={(e) => setSelectedColor(e.target.value)}
          />
        </div>

        <div className="brush-size">
          <label>Brush Size:</label>
          <input 
            type="range" 
            min="1" 
            max="5" 
            value={brushSize}
            onChange={(e) => setBrushSize(parseInt(e.target.value))}
          />
          <span>{brushSize}</span>
        </div>

        <button onClick={handleClear} className="btn btn-secondary">
          Clear
        </button>

        <button onClick={handleSave} className="btn btn-primary">
          Save
        </button>
      </div>

      <VoxelViewer voxelData={voxels} interactive={true} />
    </div>
  )
}
  