import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { useWalletStore } from '../store/walletStore'
import '../styles/Navigation.css'

export default function Navigation() {
  const { account, connectWallet, disconnectWallet } = useWalletStore()
  const [isConnecting, setIsConnecting] = useState(false)

  const handleConnectWallet = async () => {
    setIsConnecting(true)
    try {
      await connectWallet()
    } catch (error) {
      console.error('Failed to connect wallet:', error)
    }
    setIsConnecting(false)
  }

  return (
    <nav className="navbar">
      <div className="nav-container">
        <Link to="/" className="nav-logo">
          <span className="logo-icon">🎲</span> VoxelHolo
        </Link>
        
        <div className="nav-menu">
          <Link to="/" className="nav-link">Home</Link>
          <Link to="/marketplace" className="nav-link">Marketplace</Link>
          <Link to="/create" className="nav-link">Create</Link>
        </div>

        <div className="nav-auth">
          {account ? (
            <>
              <span className="account-address">{account.slice(0, 6)}...{account.slice(-4)}</span>
              <button onClick={disconnectWallet} className="btn btn-secondary">
                Disconnect
              </button>
            </>
          ) : (
            <button 
              onClick={handleConnectWallet} 
              disabled={isConnecting}
              className="btn btn-primary"
            >
              {isConnecting ? 'Connecting...' : 'Connect Wallet'}
            </button>
          )}
        </div>
      </div>
    </nav>
  )
}
  