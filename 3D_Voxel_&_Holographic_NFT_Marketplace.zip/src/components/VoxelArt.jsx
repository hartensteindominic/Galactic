import { useMemo } from 'react'

export default function VoxelArt({ voxelData }) {
  const voxels = useMemo(() => {
    const result = []
    if (!voxelData) return result
    
    voxelData.forEach((voxel, index) => {
      if (voxel.active) {
        result.push(
          <mesh key={index} position={[voxel.x, voxel.y, voxel.z]}>
            <boxGeometry args={[1, 1, 1]} />
            <meshStandardMaterial color={voxel.color} />
          </mesh>
        )
      }
    })
    return result
  }, [voxelData])

  return <group>{voxels}</group>
}
  