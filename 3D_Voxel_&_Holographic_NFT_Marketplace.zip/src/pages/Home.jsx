import { Link } from 'react-router-dom'
import Navigation from '../components/Navigation'
import '../styles/Home.css'

export default function Home() {
  return (
    <>
      <Navigation />
      <main className="home-container">
        <section className="hero">
          <h1>VoxelArt NFT Marketplace</h1>
          <p>Create, collect, and trade unique voxel art NFTs</p>
          <Link to="/marketplace" className="btn btn-primary btn-large">
            Explore Marketplace
          </Link>
        </section>

        <section className="featured">
          <h2>Featured Collections</h2>
          <div className="collection-grid">
            <div className="collection-card">
              <div className="collection-preview"></div>
              <h3>Abstract Voxels</h3>
              <p>Modern and colorful voxel creations</p>
            </div>
            <div className="collection-card">
              <div className="collection-preview"></div>
              <h3>Pixel Characters</h3>
              <p>Collectible voxel character NFTs</p>
            </div>
            <div className="collection-card">
              <div className="collection-preview"></div>
              <h3>Geometric Shapes</h3>
              <p>Minimalist geometric voxel art</p>
            </div>
          </div>
        </section>

        <section className="how-it-works">
          <h2>How It Works</h2>
          <div className="steps">
            <div className="step">
              <div className="step-number">1</div>
              <h3>Connect Wallet</h3>
              <p>Link your Web3 wallet to get started</p>
            </div>
            <div className="step">
              <div className="step-number">2</div>
              <h3>Create Voxel Art</h3>
              <p>Use our editor to create unique designs</p>
            </div>
            <div className="step">
              <div className="step-number">3</div>
              <h3>Mint NFT</h3>
              <p>Convert your art into an NFT</p>
            </div>
            <div className="step">
              <div className="step-number">4</div>
              <h3>Sell on Marketplace</h3>
              <p>List your NFTs for sale</p>
            </div>
          </div>
        </section>
      </main>
    </>
  )
}
  