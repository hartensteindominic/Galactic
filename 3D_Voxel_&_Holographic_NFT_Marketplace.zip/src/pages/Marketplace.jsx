import { useState, useEffect } from 'react'
import Navigation from '../components/Navigation'
import '../styles/Marketplace.css'

export default function Marketplace() {
  const [nfts, setNfts] = useState([])
  const [filter, setFilter] = useState('all')

  useEffect(() => {
    // Mock data - in production, fetch from blockchain
    const mockNFTs = [
      { id: 1, name: 'Abstract Voxel #1', price: '0.5', creator: '0x1234...', image: '🎨' },
      { id: 2, name: 'Geometric Shape #1', price: '0.3', creator: '0x5678...', image: '🔷' },
      { id: 3, name: 'Character #1', price: '1.0', creator: '0x9abc...', image: '👾' },
      { id: 4, name: 'Abstract Voxel #2', price: '0.7