import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import Navigation from './components/Navigation'
import Home from './pages/Home'
import Marketplace from './pages/Marketplace'
import Create from './pages/Create'
import NFTDetail from './pages/NFTDetail'
import './styles/App.css'

export default function App() {
  return (
    <Router>
      <Navigation />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/marketplace" element={<Marketplace />} />
        <Route path="/create" element={<Create />} />
        <Route path="/nft/:tokenId" element={<NFTDetail />} />
      </Routes>
    </Router>
  )
}
  